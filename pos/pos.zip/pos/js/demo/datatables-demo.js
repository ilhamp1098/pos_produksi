// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#tb_customer').DataTable();
});


